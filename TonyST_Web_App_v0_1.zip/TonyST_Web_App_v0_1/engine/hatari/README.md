# Hatari engine folder

Put the compiled Hatari WebAssembly output here.

Expected examples:

1. hatari.js
2. hatari.wasm
3. hatari.data, only if your Emscripten build creates one
4. Any support files created by the build

Then add the loader script to index.html, normally near the bottom:

<script src="engine/hatari/hatari.js"></script>

After that, wire the exported Hatari Module to:

window.TonyST.attachHatariModule(Module)

The exact exported function names depend on how Hatari was compiled.
