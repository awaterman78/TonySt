# TonyST Web App v0.1

TonyST Web is a progressive web app shell for a Hatari based Atari ST emulator.

It is designed for iPhone Safari first.

## What this pack does now

1. Opens as a normal website.
2. Can be added to the iPhone home screen.
3. Has a 640 by 400 emulator canvas.
4. Lets you select a TOS or EmuTOS file.
5. Lets you select an Atari ST disk image.
6. Has touch controls.
7. Includes a service worker and web app manifest.

## What it does not do yet

It does not yet run Atari ST games, because the compiled Hatari WebAssembly engine is not included.

## Next milestone

Get Hatari WebAssembly output files:

1. hatari.js
2. hatari.wasm
3. hatari.data, only if generated

Place them here:

engine/hatari

Then wire the Hatari Module in app.js.

## Local test

From this folder, run:

python3 -m http.server 8080

Then open:

http://localhost:8080

For iPhone testing, upload to HTTPS hosting, then open in Safari and use Add to Home Screen.

## Clean rule

No commercial games or Atari TOS files are included.
