# User files

Do not publish commercial games or copyrighted Atari TOS images in this folder.

For local testing only, you can temporarily place your own legally sourced files here.

Recommended first tests:

1. EmuTOS image, for the operating system side
2. A simple public domain ST disk image
3. Then your own legally sourced Atari ST disk images
